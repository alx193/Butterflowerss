
<div class="row">
    <div class="col">
                <div class="col-md-9">
                    <div class="card">
                                <div class="card-header" ><h4>Pret</h4></div>
                                    <div class="card-body">
                                        <label>
                                            <input type="radio" name="priceSort" wire:model="priceInput" value="low-to-high" />Crescator
                                        </label>
                                        <label>
                                            <input type="radio" name="priceSort" wire:model="priceInput" value="high-to-low" />Descrescat
                                        </label>
                                    </div>
                                </div>
                    </div>
                </div>
                 <div class="col-md-10">
                            <div class="row">
                                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-md-4">
                                            <div class="product-card">
                                                <div class="product-card-img">
                                                   <?php if($productItem->new_product > 0): ?>
                                                    <label class="stock bg-success">Nou</label>
                                                    <?php else: ?>
                                                   
                                                    <?php endif; ?>
                                                    <?php if($productItem->productImages->count() > 0): ?>
                                                    <a href="<?php echo e(url('collections/'.$productItem->category->slug.'/'.$productItem->slug)); ?>">
                                                    <img src="<?php echo e(asset($productItem->productImages[0]->image)); ?>" alt="<?php echo e($productItem->name); ?>">
                                                    </a>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="product-card-body">
                                                    <a href="<?php echo e(url('collections/'.$productItem->category->slug.'/'.$productItem->slug)); ?>">
                                                            <?php echo e($productItem->name); ?>

                                                    </a>
                                                    
                                                    <div>
                                                        <span class="selling-price"><?php echo e($productItem->selling_price); ?> RON</span>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="col-md-12">
                                            <div class="p-2">
                                                <h4>Nu sunt produse pentru categoria <?php echo e($category->name); ?></h4>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                            </div>
                </div>    
    </div>   
</div>      




<?php /**PATH /Users/mihai.pantazi/Sites/Laravelwebapps/Butterflowerss/resources/views/livewire/frontend/product/index.blade.php ENDPATH**/ ?>