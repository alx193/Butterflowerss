<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    
  

    <link rel="icon" type="image/x-icon" href="<?php echo e(url('assets/images/rotund1.ico')); ?>">

    <meta name="description" content="<?php echo $__env->yieldContent('meta_description'); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('meta_keyword'); ?>">
    <meta name="description" content="">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">

     <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
     
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">

    
     <link href="<?php echo e(asset('assets/exzoom/jquery.exzoom.css')); ?>" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('assets/css/custom.min.css')); ?>" rel="stylesheet"> 


    
</head>
<body>
    <div id="app">

    

        <?php echo $__env->make('layouts.inc.frontend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main>
                            <div class="copyright-areaa">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <p class="">Florile sunt cuvintele iubirii si respectului!</p>
                                            <p>
                                                <a href="tel:+40721332458">Comanda acum : 0721 332 458</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>   
                            </div>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
            
        <?php echo $__env->make('layouts.inc.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/exzoom/jquery.exzoom.js')); ?>"></script>
     
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>

    <?php echo $__env->yieldContent('scripts'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>

    
</body>
</html>
<?php /**PATH /Users/mihai.pantazi/Sites/Laravelwebapps/Butterflowerss/resources/views/layouts/app.blade.php ENDPATH**/ ?>