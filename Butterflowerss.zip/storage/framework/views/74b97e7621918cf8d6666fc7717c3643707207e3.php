<?php $__env->startSection('title'); ?>
<?php echo e($category->meta_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_keyword'); ?>
<?php echo e($category->meta_keyword); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_description'); ?>
<?php echo e($category->meta_description); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="mb-4">Produse</h4>
                </div>
                
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.product.index', ['products' => $products,'category' => $category])->html();
} elseif ($_instance->childHasBeenRendered('ik4abi0')) {
    $componentId = $_instance->getRenderedChildComponentId('ik4abi0');
    $componentTag = $_instance->getRenderedChildComponentTagName('ik4abi0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ik4abi0');
} else {
    $response = \Livewire\Livewire::mount('frontend.product.index', ['products' => $products,'category' => $category]);
    $html = $response->html();
    $_instance->logRenderedChild('ik4abi0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mihai.pantazi/Sites/Laravelwebapps/Butterflowerss/resources/views/frontend/collections/products/index.blade.php ENDPATH**/ ?>