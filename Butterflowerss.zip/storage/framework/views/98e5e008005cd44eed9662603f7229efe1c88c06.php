
        <nav clas="top-sticky">
                    <input type="checkbox" id="check">
                    <label for="check" class="checkbtn">
                        <i class="fa fa-bars"></i>
                    </label>
                    <a class="logo" href="/" title="Floraria ButterFlowerss">
                        <img src="<?php echo e(url('assets/images/rotund2.png')); ?>" class="img-responsive">
                    </a>

                    <ul>
                    <li><a class="active" href="<?php echo e(url('/collections')); ?>">Categorii</a></li>
                    <li><a class="active" href="<?php echo e(url('/frontend/infopages/story')); ?>">Povestea Noastra</a></li>
                    <li><a class="active" href="<?php echo e(url('/frontend/infopages/contact')); ?>">Contact</a></li>

                    
                    
                    


                    
                    
                    
                    </ul>
        </nav><?php /**PATH /Users/mihai.pantazi/Sites/Laravelwebapps/Butterflowerss/resources/views/layouts/inc/frontend/navbar.blade.php ENDPATH**/ ?>