<?php $__env->startSection('content'); ?>

<div class="row">
            <div class="col-md-12">
                <?php if(session('message')): ?>
                    <h5 class="alert alert-success mb-2"><?php echo e(session('message')); ?></h5>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h3>Edit Product
                            <a href="<?php echo e(url('admin/products/')); ?>" class="btn btn-danger btn-sm text-white float-end">
                                BACK</a>
                        </h3>
                    </div>
                        <div class="card-body">     
                                <?php if($errors->any()): ?>
                                <div class="alert alert-warning">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div><?php echo e($error); ?></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endif; ?>

                            <form action="<?php echo e(url('admin/products/'.$product->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">
                                            Home</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="seotag-tab" data-bs-toggle="tab" data-bs-target="#seotag-pane" type="button" role="tab" aria-controls="seotag-pane" aria-selected="false">
                                            SEO Tags</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="image-tab" data-bs-toggle="tab" data-bs-target="#details-tab-pane" type="button" role="tab" aria-controls="details-tab-pane" aria-selected="false"> 
                                            Details</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="image-tab" data-bs-toggle="tab" data-bs-target="#image-tab-pane" type="button" role="tab" aria-controls="image-tab-pane" aria-selected="false"> 
                                            Product Image</button>
                                    </li>
                                </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane border p-4 fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                                            <div class="mb3">
                                                <label>Select Category</label>
                                                <select name="category_id" class="form-control">
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $product->category_id ? 'selected':''); ?>>
                                                        <?php echo e($category->name); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="mb3">
                                                <label>Product Name</label>
                                                <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control">                                            
                                            </div>
                                            <div class="mb3">
                                                <label>Product Slug</label>
                                                <input type="text" name="slug" value="<?php echo e($product->slug); ?>" class="form-control">
                                            </div>
                                            <div class="mb3">
                                                <label>Small Description (500 Words)</label>
                                                <textarea name="small_description" class="form-control" rows="4"><?php echo e($product->small_description); ?></textarea>
                                            </div>
                                            <div class="mb3">
                                                <label>Description</label>
                                                <textarea name="description" class="form-control" rows="4"><?php echo e($product->description); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="tab-pane border p-4 fade" id="seotag-pane" role="tabpanel" aria-labelledby="seotag" tabindex="0">
                                                <div class="mb3">
                                                    <label>Meta  Title</label>
                                                    <textarea name="meta_title" class="form-control" rows="4"><?php echo e($product->meta_title); ?></textarea>
                                                </div>
                                                <div class="mb3">
                                                    <label>Meta Keyword</label>
                                                    <input type="text" name="meta_keyword" value="<?php echo e($product->meta_keyword); ?>" class="form-control">
                                                </div>
                                                <div class="mb3">
                                                    <label>Meta Description</label>
                                                    <input type="text" name="meta_description" value="<?php echo e($product->description); ?>" class="form-control">
                                            </div>
                                        </div>
                                        <div class="tab-pane border p-4 fade" id="details-tab-pane" role="tabpanel" aria-labelledby="details-tab" tabindex="0">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="mb-3">
                                                        <div class="mb3">
                                                            <label>Original Price</label>
                                                            <input type="text" name="original_price" value="<?php echo e($product->original_price); ?>" class="form-control" rows="4">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="mb-3">
                                                        <div class="mb3">
                                                            <label>Selling Price</label>
                                                            <input type="text" name="selling_price" value="<?php echo e($product->selling_price); ?>" class="form-control" rows="4"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="mb-3">
                                                        <div class="mb3">
                                                            <label>Quantity</label>
                                                            <input type="text" name="quantity" value="<?php echo e($product->quantity); ?>" class="form-control" rows="4"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="mb-3">
                                                        <div class="mb3">
                                                            <label>Trending</label>
                                                            <input type="checkbox" name="trending" <?php echo e($product->status == '1' ? 'checked':''); ?>  style="width: 50px; height: 50px"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="mb3">
                                                            <label>Status (Produs nou)</label>
                                                            <input type="checkbox" name="status" <?php echo e($product->status == '1' ? 'checked':''); ?>  style="width: 50px; height: 50px"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="mb3">
                                                            <label>Produs Nou</label>
                                                            <input type="checkbox" name="new_product" <?php echo e($product->new_product == '1' ? 'checked':''); ?>  style="width: 50px; height: 50px"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane border p-4 fade" id="image-tab-pane" role="tabpanel" aria-labelledby="image-tab" tabindex="0">  
                                            <div class="mb-3">
                                                    <label>Upload Product Image</label>  
                                                    <input type="file" name="image[]" multiple class="form-control"/> 
                                            </div>
                                            <div>
                                                <?php if($product->productImages): ?>
                                                    <div class="row">
                                                        <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-md-2">
                                                            <img src="<?php echo e(asset($image->image)); ?>" style="width: 80px;height: 80px"
                                                                class="me-4 border" alt="Img">
                                                            <a href="<?php echo e(url('admin/product-image/'.$image->id.'/delete')); ?>" class="d-block">Remove</a>
                                                        </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php else: ?>
                                                    <h5>Ho Image Added</h5>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                            </form>
                    </div>
                </div>
            </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mihai.pantazi/Sites/Laravelwebapps/Butterflowerss/resources/views/admin/products/edit.blade.php ENDPATH**/ ?>