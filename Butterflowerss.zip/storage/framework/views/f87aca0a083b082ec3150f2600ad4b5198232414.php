<nav class="navbar bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="/resources/images/rotund.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
      Floraria Butterflowerss
    </a>
  </div>
</nav><?php /**PATH /Users/mihai.pantazi/Sites/Laravelwebapps/Butterflowerss/resources/views/test.blade.php ENDPATH**/ ?>