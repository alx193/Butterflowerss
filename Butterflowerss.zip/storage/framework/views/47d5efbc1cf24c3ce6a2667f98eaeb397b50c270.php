<!doctype html>
<html lang="ro">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Butterflowerss Produse</title>

</head>
<body>
    <div class="py-3 py-md-4">
        <div class="container">
            <div class="row">
                <div class="col-md-3 mt-3">
                <img src="<?php echo e(asset($product->productImages[0]->image)); ?>"  class="w-100" alt="Img">
                    
                </div>
                <div class="col-md-9 mt-3">
                    <div class="product-view">
                        <h4 class="product-name">
                            <?php echo e($product->name); ?>

                        </h4>
                        <hr>
                        <a class="product-path">
                            <p> Acasa / <?php echo e($product->category->name); ?>  / <?php echo e($product->name); ?> </p>
                        </a>
                        <div>
                            <span class="selling-price"><?php echo e($product->selling_price); ?> RON</span>
                            
                        </div>
                        
                        
                        
                        <div class="row"> <br>
                            <div class="col-md-12 mt-5">
                                <div class="card1">
                                    <div class="card-header bg-white">
                                            <h4>Optiuni Personalizare</h4>
                                    </div>
                                          <div class="card-body">
                                             <p>
                                                <?php echo e($product->small_description); ?>

                                             </p>
                                          </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mt-5">
                    <div class="card1">
                        <div class="card-header bg-white">
                            <h4>Descriere</h4>
                        </div>
                        <div class="card-body">
                            <p>
                                <?php echo e($product->description); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    
</body>
</html><?php /**PATH /Users/mihai.pantazi/Sites/Laravelwebapps/Butterflowerss/resources/views/livewire/frontend/product/view.blade.php ENDPATH**/ ?>