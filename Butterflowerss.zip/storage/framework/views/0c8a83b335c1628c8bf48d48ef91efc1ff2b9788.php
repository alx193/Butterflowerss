<?php $__env->startSection('title', 'Povestea Noastra'); ?>

<?php $__env->startSection('content'); ?>

<div class="story">
    <p>
            Pasiunea a devenit vis..visul s-a transformat in realitate si asa a luat nastere FLORARIA BUTTERFLOWERSS.
        Fluturii sunt speranta, florile sunt dragoste si astfel noi, sperand la infaptuire si iubind furmosul, am reusit
    sa cream acest concept cu gandul la florile din gradina bunicilor, care ne inmiresmau diminetile de vacante...si asa ne dorim 
    si clientii sa se simta cand parasesc magazinul nostru.
        Fiecare aranjament este lucrat cu dragoste, iar fiecare floare este ingrijita cu iubire. Din aceasta dragoste fata de plante 
    a luat nastere si motto-ul nostru "Florile sunt cuvintele iubirii si respectului". Astfel muncim zi de zi cu pasiune, din respect pentru Dumneavoastra 
    si iubire pentru flori oferind un catalog larg de aranjamente si buchete deosebite, fiecare dintre acestea fiind alcatuite din flori si plante atent alese pentru 
    a oferi o experienta vizuala unica si o senzatie olfactiva fabuloasa.
    </p>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mihai.pantazi/Sites/Laravelwebapps/Butterflowerss/resources/views/frontend/infopages/story.blade.php ENDPATH**/ ?>