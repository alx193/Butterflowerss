<?php $__env->startSection('title', 'Floraria butterflowerss'); ?>

                    

<?php $__env->startSection('content'); ?>

                    
    







        <div class="py-1">
            <div class="container">
                <div class="row justify-content-cnter">
                    <div class="col-md-8 text-left">
                    <?php if($newArrivalsProducts->count() > 0): ?>
                        <h4>Produse Noi</h4>
                        <div class="underline"></div>
                    <?php else: ?> 

                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="py-3">
            <div class="container">
                <div class="row">
                <?php if($newArrivalsProducts): ?>
                    <div class="col-md-12">
                    <div class="owl-carousel owl-theme four-carousel">
                        <?php $__currentLoopData = $newArrivalsProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="product-card">
                                    <div class="product-card-img">
                                        <label class="stock bg-success">Nou</label>
                                        <?php if($productItem->productImages->count() > 0): ?>
                                        <a href="<?php echo e(url('collections/'.$productItem->category->slug.'/'.$productItem->slug)); ?>">
                                        <img src="<?php echo e(asset($productItem->productImages[0]->image)); ?>" alt="<?php echo e($productItem->name); ?>">
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                    <div class="product-card-body">
                                        <a href="<?php echo e(url('collections/'.$productItem->category->slug.'/'.$productItem->slug)); ?>">
                                                <?php echo e($productItem->name); ?>

                                        </a>
                                        </h5>
                                        <div>
                                            <span class="selling-price"><?php echo e($productItem->selling_price); ?> RON</span>
                                            
                                        </div>
                                    </div>
                                </div>       
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> 
                    </div>
                <?php else: ?>
                        <div class="col-md-12">
                            <div class="p-2">
                                <h4>Nu exista produse noi</h4>
                            </div>
                        </div>
                <?php endif; ?>
                
            </div>
        </div>



<div class="py-1">
    <div class="container">
        <div class="row justify-content-cnter">
            <div class="col-md-8 text-left">
            <?php if($trendingProducts->count() > 0): ?>
                <h4>Produse populare</h4>
                <div class="underline"></div>
             <?php else: ?> 

            <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="py-3">
    <div class="container">
        <div class="row">
        <?php if($trendingProducts): ?>
              <div class="col-md-12">
              <div class="owl-carousel owl-theme four-carousel">
                  <?php $__currentLoopData = $trendingProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="item">
                          <div class="product-card">
                              <div class="product-card-img">
                                  
                                  <?php if($productItem->productImages->count() > 0): ?>
                                  <a href="<?php echo e(url('collections/'.$productItem->category->slug.'/'.$productItem->slug)); ?>">
                                  <img src="<?php echo e(asset($productItem->productImages[0]->image)); ?>" alt="<?php echo e($productItem->name); ?>">
                                  </a>
                                  <?php endif; ?>
                              </div>
                              <div class="product-card-body">
                                  <a href="<?php echo e(url('collections/'.$productItem->category->slug.'/'.$productItem->slug)); ?>">
                                          <?php echo e($productItem->name); ?>

                                  </a>
                                  </h5>
                                  <div>
                                      <span class="selling-price"><?php echo e($productItem->selling_price); ?> RON</span>
                                      
                                  </div>
                              </div>
                          </div>       
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div> 
              </div>
              <?php else: ?>
                  <div class="col-md-12">
                      <div class="p-2">
                          <h4>No Products Available</h4>
                      </div>
                  </div>
        <?php endif; ?>
        </div>
    </div>
</div>






<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$('.four-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:4
        }
    }
})

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mihai.pantazi/Sites/Laravelwebapps/Butterflowerss/resources/views/frontend/index.blade.php ENDPATH**/ ?>