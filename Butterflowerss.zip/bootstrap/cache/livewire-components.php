<?php return array (
  'admin.category.index' => 'App\\Http\\Livewire\\Admin\\Category\\Index',
  'frontend.product.index' => 'App\\Http\\Livewire\\Frontend\\Product\\Index',
  'frontend.product.view' => 'App\\Http\\Livewire\\Frontend\\Product\\View',
);